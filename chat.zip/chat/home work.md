make the input bar look nicer
	- fix color input not taking the whole hight
	- add margin between elements
	- when page loads username inputs must be focused (use javascript)
	- make the color button nicer (circular may be)